/**
 * Panamax Tonnage Parser
 * ---------------------
 * Parses raw WhatsApp tonnage messages into structured vessel objects.
 *
 * Expected message format (one or multi-line):
 *   OWNER - MV VESSEL NAME (DWT_K/YEAR) PORT DATE / ETA DATE [ONW]
 *   BOD ABT IFO/MDO
 *   = ROUTE: Claims seeing BID [multiple times] vs OFFER (p6: P6_BID vs P6_OFFER)
 *
 * Example:
 *   QUADRA - MV SAKIZAYA MIRACLE (81/17) GOA 31 MARCH / ETA 25 APR ONW
 *   BOD ABT 1250/240
 *   = ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)
 */

// ─── Constants ────────────────────────────────────────────────────────────────

const KNOWN_ROUTES = [
  'ECSA FH',
  'ECSA TA',
  'USG FH',
  'USG TA',
  'NCSA FH',
  'USEC TA',
  'WAFR',
  'BSEA',
  'MED',
  'NOPAC',
  'PAC RV',
];

const MONTH_MAP = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6,
  jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12,
};

const CURRENT_YEAR = new Date().getFullYear();

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * Normalise rate strings like "20k", "20,000", "20.5k" → number
 */
function parseRate(str) {
  if (!str) return null;
  const s = str.replace(/,/g, '').trim().toLowerCase();
  const kMatch = s.match(/^(\d+(?:\.\d+)?)k$/);
  if (kMatch) return Math.round(parseFloat(kMatch[1]) * 1000);
  const plain = parseFloat(s);
  return isNaN(plain) ? null : plain;
}

/**
 * Parse date strings like "31 MARCH", "25 APR", "31 MAR"
 * Returns ISO date string (YYYY-MM-DD) or null
 */
function parseDate(str) {
  if (!str) return null;
  const clean = str.trim().toLowerCase().replace(/[.,]/g, '');
  const match = clean.match(/(\d{1,2})\s+([a-z]+)(?:\s+(\d{4}))?/);
  if (!match) return null;
  const day = parseInt(match[1], 10);
  const month = MONTH_MAP[match[2].slice(0, 3)];
  const year = match[3] ? parseInt(match[3], 10) : CURRENT_YEAR;
  if (!month) return null;
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

/**
 * Detect scrubber from vessel name or trailing flags
 * Common markers: S, SCR, SCRUBBER, +S
 */
function detectScrubber(text) {
  if (/\bscr(ubber)?\b|\+s\b/i.test(text)) return true;
  return null; // null = unknown (not explicitly stated)
}

// ─── Line Parsers ─────────────────────────────────────────────────────────────

/**
 * Parse line 1: vessel identity + position
 * Format: OWNER - MV VESSEL NAME (DWT/YEAR) PORT OPEN_DATE / ETA ETA_DATE [ONW]
 *
 * Returns partial vessel object.
 */
function parseVesselLine(line) {
  const result = {
    source: null,
    vessel_name: null,
    dwt: null,
    build_year: null,
    scrubber: null,
    current_position: null,
    open_date: null,
    eta_ecsa: null,
    eta_type: null, // 'ONW' | 'EXACT' | 'RANGE'
    delivery_basis: null,
  };

  // Split on ' - ' to get source (owner) and the rest
  const dashIdx = line.indexOf(' - ');
  if (dashIdx !== -1) {
    result.source = line.slice(0, dashIdx).trim();
    line = line.slice(dashIdx + 3);
  }

  // Extract (DWT/YEAR) e.g. (81/17) or (82000/2017)
  const sizeMatch = line.match(/\((\d+)\/(\d{2,4})\)/);
  if (sizeMatch) {
    const dwtRaw = parseInt(sizeMatch[1], 10);
    result.dwt = dwtRaw < 1000 ? dwtRaw * 1000 : dwtRaw; // normalise thousands
    const yearRaw = parseInt(sizeMatch[2], 10);
    result.build_year = yearRaw < 100 ? 2000 + yearRaw : yearRaw;
    line = line.replace(sizeMatch[0], '').trim();
  }

  // Check scrubber flags in remaining text
  result.scrubber = detectScrubber(line);

  // Extract ETA section: everything after '/ ETA' or '/ETA'
  const etaMatch = line.match(/\/\s*ETA\s+(.+)$/i);
  if (etaMatch) {
    const etaStr = etaMatch[1].trim();
    const onw = /\bonw\b/i.test(etaStr);
    result.eta_type = onw ? 'ONW' : 'EXACT';
    const etaClean = etaStr.replace(/\bonw\b/gi, '').trim();
    result.eta_ecsa = parseDate(etaClean);
    line = line.slice(0, line.indexOf('/')).trim();
  }

  // What remains: MV? VESSEL_NAME PORT OPEN_DATE
  // Strip MV / MT prefix
  line = line.replace(/^M[VT]\s+/i, '').trim();

  // Delivery basis detection: look for APS ECSA, APS PORT, DLOSP, PASSING etc.
  // Do this BEFORE name parsing so we can strip it from the vessel name
  const deliveryMatch = line.match(/\b(APS\s+\w+|DLOSP|PASSING\s+\w+|SANTOS|PARANAGUA)\b/i);
  if (deliveryMatch) {
    result.delivery_basis = deliveryMatch[1].toUpperCase();
    // Remove the delivery basis token from the line to avoid it polluting the name
    line = line.replace(deliveryMatch[0], '').replace(/\s{2,}/g, ' ').trim();
  }

  // Try to extract vessel name (uppercase words) then port + date
  // Strategy: find last date occurrence — everything before last date chunk is name + port
  const datePattern = /(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*)/gi;
  const allDates = [...line.matchAll(datePattern)];

  if (allDates.length > 0) {
    const lastDate = allDates[allDates.length - 1];
    result.open_date = parseDate(lastDate[0]);
    const beforeDate = line.slice(0, lastDate.index).trim();

    // Last word before date is typically the port
    const parts = beforeDate.split(/\s+/).filter(Boolean);
    if (parts.length >= 1) {
      result.current_position = parts[parts.length - 1];
      result.vessel_name = parts.slice(0, parts.length - 1).join(' ') || beforeDate;
    }
  } else {
    // No date found — check if delivery basis was already extracted; remaining is vessel name
    // Strip any trailing port-like tokens (single ALL-CAPS word at end)
    const parts = line.trim().split(/\s+/).filter(Boolean);
    if (parts.length > 1 && /^[A-Z]+$/.test(parts[parts.length - 1]) && parts[parts.length - 1].length <= 5) {
      result.current_position = parts[parts.length - 1];
      result.vessel_name = parts.slice(0, parts.length - 1).join(' ');
    } else {
      result.vessel_name = line.trim() || null;
    }
  }

  // Clean vessel name — trim any stray punctuation
  if (result.vessel_name) {
    result.vessel_name = result.vessel_name.replace(/^\s*[-/]\s*|\s*[-/]\s*$/g, '').trim();
  }

  return result;
}

/**
 * Parse BOD line: "BOD ABT 1250/240"
 */
function parseBODLine(line) {
  const match = line.match(/BOD\s+(?:ABT\s+)?(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/i);
  if (!match) return { bod_ifo: null, bod_mdo: null };
  return {
    bod_ifo: parseFloat(match[1]),
    bod_mdo: parseFloat(match[2]),
  };
}

/**
 * Parse market colour line(s):
 * "= ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)"
 *
 * Returns array of route objects:
 * { route, bid_usd, offer_usd, p6_bid, p6_offer, bid_multiple_claims }
 */
function parseMarketColourLine(line) {
  // Strip leading = and whitespace
  line = line.replace(/^[=\s]+/, '').trim();

  // Attempt to identify route at start (before colon)
  let route = null;
  const colonIdx = line.indexOf(':');
  if (colonIdx !== -1) {
    const candidate = line.slice(0, colonIdx).trim().toUpperCase();
    // Accept if it matches known routes or looks like a route pattern
    route = candidate;
    line = line.slice(colonIdx + 1).trim();
  }

  // Detect "multiple times" flag on bid
  const multipleTimes = /multiple\s+times/i.test(line);

  // Extract p6 equivalents: (p6: X vs Y)
  let p6_bid = null;
  let p6_offer = null;
  const p6Match = line.match(/\(\s*p6\s*:\s*([0-9k,.\s]+)\s+vs\s+([0-9k,.\s]+)\s*\)/i);
  if (p6Match) {
    p6_bid = parseRate(p6Match[1].trim());
    p6_offer = parseRate(p6Match[2].trim());
    // Remove p6 section from line for cleaner bid/offer extraction
    line = line.replace(p6Match[0], '').trim();
  }

  // Extract main bid vs offer: "Claims seeing X ... vs Y"
  let bid_usd = null;
  let offer_usd = null;
  const vsMatch = line.match(/claims\s+seeing\s+([0-9k,.\s]+?)(?:\s+multiple\s+times)?\s+vs\s+([0-9k,.\s]+)/i);
  if (vsMatch) {
    bid_usd = parseRate(vsMatch[1].trim());
    offer_usd = parseRate(vsMatch[2].trim());
  } else {
    // Fallback: just look for X vs Y
    const simpleVs = line.match(/([0-9k,.]+)\s+vs\s+([0-9k,.]+)/i);
    if (simpleVs) {
      bid_usd = parseRate(simpleVs[1]);
      offer_usd = parseRate(simpleVs[2]);
    }
  }

  return {
    route,
    bid_usd,
    offer_usd,
    bid_multiple_claims: multipleTimes,
    p6_bid,
    p6_offer,
  };
}

// ─── Main Parser ──────────────────────────────────────────────────────────────

/**
 * Parse a full raw WhatsApp tonnage message.
 *
 * @param {string} rawText - Raw WhatsApp message text (may be multi-line)
 * @returns {object} Structured vessel object
 */
function parseTonnageMessage(rawText) {
  const lines = rawText
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean);

  const vessel = {
    // Identity
    source: null,
    vessel_name: null,
    dwt: null,
    build_year: null,
    scrubber: null,

    // Position
    current_position: null,
    open_date: null,
    eta_ecsa: null,
    eta_type: null,
    delivery_basis: null,

    // Bunkers
    bod_ifo: null,
    bod_mdo: null,

    // Market colour (array, one entry per route mentioned)
    market_colour: [],

    // Metadata
    raw: rawText,
    parsed_at: new Date().toISOString(),
    parse_warnings: [],
  };

  for (const line of lines) {
    // BOD line
    if (/^BOD\b/i.test(line)) {
      const bod = parseBODLine(line);
      Object.assign(vessel, bod);
      continue;
    }

    // Market colour line (starts with = or contains 'claims seeing' / known route + colon)
    if (/^=/.test(line) || /claims\s+seeing/i.test(line)) {
      const colour = parseMarketColourLine(line);
      if (colour.route || colour.bid_usd || colour.p6_bid) {
        vessel.market_colour.push(colour);
      }
      continue;
    }

    // Vessel line (first non-BOD, non-colour line assumed to be vessel line)
    if (!vessel.vessel_name && !vessel.source) {
      const vesselData = parseVesselLine(line);
      Object.assign(vessel, vesselData);
      continue;
    }

    // Unmatched lines — store as warning
    vessel.parse_warnings.push(`Unmatched line: "${line}"`);
  }

  // Validation warnings
  if (!vessel.vessel_name) vessel.parse_warnings.push('Could not extract vessel name');
  if (!vessel.eta_ecsa) vessel.parse_warnings.push('No ETA extracted');
  if (vessel.market_colour.length === 0) vessel.parse_warnings.push('No market colour parsed');

  return vessel;
}

/**
 * Parse multiple messages (e.g. pasted block from WhatsApp group).
 * Messages are assumed to be separated by blank lines.
 *
 * @param {string} rawBlock - Multi-message block
 * @returns {Array<object>} Array of parsed vessel objects
 */
function parseMultipleMessages(rawBlock) {
  const messages = rawBlock
    .split(/\n{2,}/)
    .map(m => m.trim())
    .filter(Boolean);

  return messages.map(parseTonnageMessage);
}

// ─── Exports ──────────────────────────────────────────────────────────────────

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    parseTonnageMessage,
    parseMultipleMessages,
    parseRate,
    parseDate,
    // expose sub-parsers for unit testing
    parseVesselLine,
    parseBODLine,
    parseMarketColourLine,
  };
}
