/**
 * Parser Tests
 * ------------
 * Run with: node src/parser.test.js
 * No test framework required — plain assertions.
 */

const {
  parseTonnageMessage,
  parseMultipleMessages,
  parseRate,
  parseDate,
  parseVesselLine,
  parseBODLine,
  parseMarketColourLine,
} = require('./parser');

// ─── Helpers ──────────────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function assert(condition, label) {
  if (condition) {
    console.log(`  ✓ ${label}`);
    passed++;
  } else {
    console.error(`  ✗ ${label}`);
    failed++;
  }
}

function assertEqual(actual, expected, label) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    console.log(`  ✓ ${label}`);
    passed++;
  } else {
    console.error(`  ✗ ${label}`);
    console.error(`    expected: ${JSON.stringify(expected)}`);
    console.error(`    actual:   ${JSON.stringify(actual)}`);
    failed++;
  }
}

function section(name) {
  console.log(`\n── ${name} ──`);
}

// ─── Unit Tests ───────────────────────────────────────────────────────────────

section('parseRate');
assertEqual(parseRate('20k'),    20000, '20k → 20000');
assertEqual(parseRate('21,500'), 21500, '21,500 → 21500');
assertEqual(parseRate('16,700'), 16700, '16,700 → 16700');
assertEqual(parseRate('18k'),    18000, '18k → 18000');
assertEqual(parseRate('20.5k'),  20500, '20.5k → 20500');
assertEqual(parseRate(null),     null,  'null → null');

section('parseDate');
assertEqual(parseDate('31 MARCH'),   `${new Date().getFullYear()}-03-31`, '31 MARCH');
assertEqual(parseDate('25 APR'),     `${new Date().getFullYear()}-04-25`, '25 APR');
assertEqual(parseDate('1 JAN 2027'), '2027-01-01',                       '1 JAN 2027 explicit year');
assertEqual(parseDate(null),         null,                                'null → null');

section('parseBODLine');
assertEqual(
  parseBODLine('BOD ABT 1250/240'),
  { bod_ifo: 1250, bod_mdo: 240 },
  'BOD ABT 1250/240'
);
assertEqual(
  parseBODLine('BOD 800/150'),
  { bod_ifo: 800, bod_mdo: 150 },
  'BOD without ABT'
);
assertEqual(
  parseBODLine('some other line'),
  { bod_ifo: null, bod_mdo: null },
  'non-BOD line returns nulls'
);

section('parseMarketColourLine');
const mc = parseMarketColourLine('= ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)');
assertEqual(mc.route,               'ECSA FH', 'route');
assertEqual(mc.bid_usd,             20000,     'bid_usd');
assertEqual(mc.offer_usd,           21500,     'offer_usd');
assertEqual(mc.p6_bid,              16700,     'p6_bid');
assertEqual(mc.p6_offer,            18000,     'p6_offer');
assertEqual(mc.bid_multiple_claims, true,      'bid_multiple_claims');

section('parseVesselLine — full example');
const vl = parseVesselLine('QUADRA - MV SAKIZAYA MIRACLE (81/17) GOA 31 MARCH / ETA 25 APR ONW');
assertEqual(vl.source,           'QUADRA',                           'source');
assertEqual(vl.vessel_name,      'SAKIZAYA MIRACLE',                 'vessel_name');
assertEqual(vl.dwt,              81000,                              'dwt');
assertEqual(vl.build_year,       2017,                               'build_year');
assertEqual(vl.current_position, 'GOA',                             'current_position');
assertEqual(vl.open_date,        `${new Date().getFullYear()}-03-31`, 'open_date');
assertEqual(vl.eta_ecsa,         `${new Date().getFullYear()}-04-25`, 'eta_ecsa');
assertEqual(vl.eta_type,         'ONW',                              'eta_type');

section('parseTonnageMessage — full integration');
const raw = `QUADRA - MV SAKIZAYA MIRACLE (81/17) GOA 31 MARCH / ETA 25 APR ONW
BOD ABT 1250/240
= ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)`;

const v = parseTonnageMessage(raw);
assertEqual(v.source,              'QUADRA',   'source');
assertEqual(v.vessel_name,         'SAKIZAYA MIRACLE', 'vessel_name');
assertEqual(v.dwt,                 81000,      'dwt');
assertEqual(v.build_year,          2017,       'build_year');
assertEqual(v.current_position,    'GOA',      'current_position');
assertEqual(v.bod_ifo,             1250,       'bod_ifo');
assertEqual(v.bod_mdo,             240,        'bod_mdo');
assertEqual(v.market_colour.length, 1,         'one market colour entry');
assertEqual(v.market_colour[0].route,     'ECSA FH', 'market_colour[0].route');
assertEqual(v.market_colour[0].p6_bid,    16700,     'market_colour[0].p6_bid');
assertEqual(v.market_colour[0].p6_offer,  18000,     'market_colour[0].p6_offer');
assert(v.parse_warnings.length === 0, 'no parse warnings');

section('parseMultipleMessages — two vessels');
const block = `QUADRA - MV SAKIZAYA MIRACLE (81/17) GOA 31 MARCH / ETA 25 APR ONW
BOD ABT 1250/240
= ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)

STAR BULK - MV STAR CHARIS (82/13) APS ECSA / ETA 13 APR
= ECSA TA: Claims seeing 18,500 vs 19,500 (p6: 15,000 vs 16,000)`;

const vessels = parseMultipleMessages(block);
assertEqual(vessels.length, 2, 'two vessels parsed');
assertEqual(vessels[0].vessel_name, 'SAKIZAYA MIRACLE', 'first vessel name');
assertEqual(vessels[1].vessel_name, 'STAR CHARIS',      'second vessel name');
assertEqual(vessels[1].market_colour[0].route, 'ECSA TA', 'second vessel route');

// ─── Summary ──────────────────────────────────────────────────────────────────

console.log(`\n${'─'.repeat(40)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
