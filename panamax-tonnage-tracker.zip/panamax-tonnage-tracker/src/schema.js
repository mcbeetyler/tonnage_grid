/**
 * Vessel Data Schema
 * ------------------
 * Defines the canonical vessel object structure used throughout the tool.
 * Used as documentation for Claude Code when extending the dashboard.
 *
 * All monetary values are USD/day (P5TC equivalent where normalised).
 * All quantities in metric tonnes.
 * All dates as ISO 8601 strings (YYYY-MM-DD).
 */

/**
 * @typedef {Object} MarketColour
 * @property {string|null}  route               - Route label e.g. 'ECSA FH', 'ECSA TA'
 * @property {number|null}  bid_usd             - Owner-claimed bid side (raw $/day, unverified)
 * @property {number|null}  offer_usd           - Owner's ask (raw $/day)
 * @property {boolean}      bid_multiple_claims - Owner claiming bid seen multiple times
 * @property {number|null}  p6_bid              - P6-normalised bid ($/day) — PRIMARY COMPARATOR
 * @property {number|null}  p6_offer            - P6-normalised offer ($/day) — PRIMARY COMPARATOR
 */

/**
 * @typedef {Object} Vessel
 *
 * — Identity —
 * @property {string|null}  source           - Owner/operator who circulated this message
 * @property {string|null}  vessel_name      - Vessel name (excluding MV/MT prefix)
 * @property {number|null}  dwt              - Deadweight tonnage (metric tonnes)
 * @property {number|null}  build_year       - Year of build
 * @property {boolean|null} scrubber         - Scrubber fitted: true/false/null (unknown)
 *
 * — Position & Availability —
 * @property {string|null}  current_position - Last known port or area (e.g. 'GOA', 'SANTOS')
 * @property {string|null}  open_date        - Date vessel is open at current_position (ISO)
 * @property {string|null}  eta_ecsa         - ETA to ECSA loading area (ISO)
 * @property {string}       eta_type         - 'ONW' | 'EXACT' | 'RANGE' | null
 *                                             ONW = earliest date, may slip
 *                                             EXACT = fixed ETA
 *                                             RANGE = date window
 * @property {string|null}  delivery_basis   - Delivery terms if stated (e.g. 'APS ECSA', 'SANTOS')
 *
 * — Bunkers on Delivery —
 * @property {number|null}  bod_ifo          - IFO quantity on delivery (mt)
 * @property {number|null}  bod_mdo          - MDO/MGO quantity on delivery (mt)
 *
 * — Market Intelligence —
 * @property {MarketColour[]} market_colour  - Rate intelligence per route (see above)
 *                                             Key field: p6_bid / p6_offer
 *                                             These are the normalised comparators across vessels
 *
 * — Status (managed by dashboard, not parser) —
 * @property {string}       status           - 'OPEN' | 'FIXED' | 'FAILED' | 'WITHDRAWN'
 * @property {string|null}  fixed_route      - Route if fixed (e.g. 'ECSA FH')
 * @property {number|null}  fixed_rate_p6    - Agreed rate as P6 equivalent ($/day)
 * @property {string|null}  fixed_at         - ISO datetime of fixture
 * @property {string|null}  notes            - Free text notes
 *
 * — Metadata —
 * @property {string}       raw              - Original raw WhatsApp text
 * @property {string}       parsed_at        - ISO datetime of parsing
 * @property {string[]}     parse_warnings   - Any fields that could not be extracted
 */

// ─── Example Objects ──────────────────────────────────────────────────────────

/**
 * Fully populated example (from the SAKIZAYA MIRACLE message)
 */
const EXAMPLE_VESSEL_FULL = {
  source: 'QUADRA',
  vessel_name: 'SAKIZAYA MIRACLE',
  dwt: 81000,
  build_year: 2017,
  scrubber: null,

  current_position: 'GOA',
  open_date: '2026-03-31',
  eta_ecsa: '2026-04-25',
  eta_type: 'ONW',
  delivery_basis: null,

  bod_ifo: 1250,
  bod_mdo: 240,

  market_colour: [
    {
      route: 'ECSA FH',
      bid_usd: 20000,
      offer_usd: 21500,
      bid_multiple_claims: true,
      p6_bid: 16700,
      p6_offer: 18000,
    },
  ],

  status: 'OPEN',
  fixed_route: null,
  fixed_rate_p6: null,
  fixed_at: null,
  notes: null,

  raw: 'QUADRA - MV SAKIZAYA MIRACLE (81/17) GOA 31 MARCH / ETA 25 APR ONW\nBOD ABT 1250/240\n= ECSA FH: Claims seeing 20k multiple times vs 21,500 (p6: 16,700 vs 18k)',
  parsed_at: '2026-03-30T09:00:00.000Z',
  parse_warnings: [],
};

/**
 * Minimal example (only identity + ETA, no BOD or market colour)
 */
const EXAMPLE_VESSEL_MINIMAL = {
  source: 'MARINAKISS',
  vessel_name: 'ARGEUS',
  dwt: 82225,
  build_year: 2013,
  scrubber: null,

  current_position: null,
  open_date: null,
  eta_ecsa: '2026-04-12',
  eta_type: 'EXACT',
  delivery_basis: 'APS ECSA',

  bod_ifo: null,
  bod_mdo: null,
  market_colour: [],

  status: 'OPEN',
  fixed_route: null,
  fixed_rate_p6: null,
  fixed_at: null,
  notes: null,

  raw: 'MARINAKISS - MV ARGEUS (82/13) APS ECSA / ETA 12 APR',
  parsed_at: '2026-03-30T09:00:00.000Z',
  parse_warnings: ['No market colour parsed', 'No open date extracted'],
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { EXAMPLE_VESSEL_FULL, EXAMPLE_VESSEL_MINIMAL };
}
